import pandas as pd
import json
import os


class CTA_SCH_Evaluator:
  def __init__(self, ground_truth_filepath, submission_filepath):
    """
    ground_truth_filepath: filepath where csv with ground truth is located.
    submission_filepath: filepath where csv with submission is located.
    """
    self.ground_truth_filepath = ground_truth_filepath
    self.submission_filepath = submission_filepath

  def _evaluate(self):
    """
    Compare submitted annotations with ground truth annotations,
    and calculate precision, recall and f1 metrics.
    """

    cols, col_type = set(), dict()
    gt = pd.read_csv(
        self.ground_truth_filepath,
        delimiter=',',
        names=['tab_id', 'col_id', 'type'],
        dtype={'tab_id': str, 'col_id': str, 'type': str},
        keep_default_na=False
    )
    for index, row in gt.iterrows():
        col = '%s %s' % (row['tab_id'], row['col_id'])
        gt_type = row['type']
        col_type[col] = gt_type
        cols.add(col)

    annotated_cols = set()
    TP = 0
    valid_annotations = 0
    submission = pd.read_csv(
        self.submission_file_path,
        delimiter=',',
        names=['tab_id', 'col_id', 'annotation'],
        dtype={'tab_id': str, 'col_id': str, 'annotation': str},
        keep_default_na=False
    )
    for index, row in submission.iterrows():
        col = '%s %s' % (row['tab_id'], row['col_id'])
        if col in annotated_cols:
            # continue
            raise Exception("Duplicate columns in the submission file")
        else:
            annotated_cols.add(col)
        annotation = row['annotation'].lower()
        if annotation.startswith('https://schema.org/'):
            annotation = annotation.replace('https://schema.org/', 'schema:')
        elif not annotation.startswith('schema:'):
            annotation = 'schema:' + annotation

        if col in cols:
            valid_annotations += 1
            gt = col_type[col]
            if gt.lower() == annotation.lower():
                TP = TP + 1

    precision = TP / valid_annotations if valid_annotations > 0 else 0
    recall = TP / len(cols)
    f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0

    main_score = f1
    secondary_score = precision

    print('%.3f %.3f %.3f' % (f1, precision, recall))

    """
    Do something with your submitted file to come up
    with a score and a secondary score.

    if you want to report back an error to the user,
    then you can simply do :
      `raise Exception("YOUR-CUSTOM-ERROR")`

     You are encouraged to add as many validations as possible
     to provide meaningful feedback to your users
    """
    _result_object = {
        "score": main_score,
        "score_secondary": secondary_score
    }
    return _result_object


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='Evaluate submission against groundtruth.')
    parser.add_argument(
        'submission_filepath',
        type=str,
        help='path of the submission file (train)'
    )
    parser.add_argument(
        'ground_truth_filepath',
        type=str,
        help='path of the ground truth file (train)'
    )

    args = parser.parse_args()

    # Instantiate an evaluator
    evaluator = CTA_SCH_Evaluator(args.ground_truth_filepath, args.submission_filepath)
    # Evaluate
    result = evaluator._evaluate()
    print(result)
